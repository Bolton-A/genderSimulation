# Code for converting Social Security Administration baby names dataset from .txt files to .xlsx files.

# Import necessary packages.
import os
import pandas as pd

# Go to directory containing the .txt files.
txt_directory = r'C:\Users\bolto\Desktop\Gender Simulation Redone\CreateDatabase\names'
# Go to directory that stores the converted .xlsx files.
xlsx_directory = r'C:\Users\bolto\Desktop\Gender Simulation Redone\CreateDatabase\convertedNames'

# Iterate through each year within the directory.
for filename in os.listdir(txt_directory):
    if filename.endswith('.txt'):

        # Open the file and save the contents.
        with open(os.path.join(txt_directory, filename), 'r') as file:
            content = file.read()

        # Split by new lines.
        rows = content.split('\n')

        # Create a pandas dataframe, starting at the first row.
        df = pd.DataFrame(rows[0:])

        # Create the Excel file.
        excel_filename = os.path.splitext(filename)[0] + '.xlsx'
        excel_filepath = os.path.join(xlsx_directory, excel_filename)

        # Save pandas dataframe to .xlsx in the exact same format as it was originally in text.
        df.to_excel(excel_filepath, index = False, header = False)

        # Print result for tracking and troubleshooting.
        print(f"Converted {filename} to {excel_filename}")

