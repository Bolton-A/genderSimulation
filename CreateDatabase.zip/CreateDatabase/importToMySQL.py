import openpyxl
import mysql.connector

# Connect to MySQL
mydb = mysql.connector.connect(
    host="127.0.0.1",
    user="password",
    passwd="password",
    port=3306
)

# Function to insert data into MySQL
def insert_data_to_mysql(data, year):
    cursor = mydb.cursor()
    cursor.execute("CREATE DATABASE IF NOT EXISTS yearsandnames2;")
    cursor.execute("USE yearsandnames2;")
    cursor.execute('''
                    CREATE TABLE IF NOT EXISTS year{0} (
                    name varchar(255),
                    gender varchar(1),
                    total int(8)
                 );
                '''.format(year))
    insert_query = "INSERT INTO year{0} (name, gender, total) VALUES (%s, %s, %s)".format(year)
    cursor.executemany(insert_query, data)
    mydb.commit()
    cursor.close()

# Iterate through files for each year
for year in range(1880, 2023):
    excel_file_path = "yob{}.xlsx".format(year)
    try:
        workbook = openpyxl.load_workbook(excel_file_path)
        sheet = workbook.active

        # Extract data from Excel sheet
        data = []
        for row in sheet.iter_rows(min_row=2, values_only=True):  # Skip header row
            if row[0]:  # Check if the cell is not empty
                values = row[0].split(',')
                if len(values) == 3:  # Ensure there are three values after splitting
                    name, gender, total = values
                    data.append((name.strip(), gender.strip(), int(total.strip())))
                else:
                    print(f"Ignoring row {row} in {excel_file_path} as it doesn't have enough values after splitting.")
            else:
                print(f"Ignoring empty row in {excel_file_path}.")

        # Insert data into MySQL
        insert_data_to_mysql(data, year)
    except FileNotFoundError:
        print(f"File {excel_file_path} not found.")

# Close MySQL connection
mydb.close()
